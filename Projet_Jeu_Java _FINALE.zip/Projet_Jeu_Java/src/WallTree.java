import java.awt.*;

public class WallTree extends SolidThings {
    public WallTree(int x, int y, Image img) {
        super(x, y, img, 8, 18, 16, 12);
    }
    }