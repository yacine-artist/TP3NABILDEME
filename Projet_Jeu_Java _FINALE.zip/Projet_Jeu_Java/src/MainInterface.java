import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.Timer;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class MainInterface extends JFrame implements KeyListener {

    private Hero hero;
    private Dungeon dungeon;
    private GameRender panel;
    private GameState gameState;

    public MainInterface() throws IOException {
        gameState = GameState.TITLE_SCREEN; // Commence sur l'écran titre
        dungeon = new Dungeon("src/resources/level1.txt");

        hero = Hero.getInstance();
        hero.image = loadHeroSpriteFromSheet("src/resources/hero.png", 0, 0);

        hero.x = 250;
        hero.y = 325;

        hero.getHitBox().setX(hero.x);
        hero.getHitBox().setY(hero.y);
        hero.getHitBox().setWidth(hero.image.getWidth(null));
        hero.getHitBox().setHeight(hero.image.getHeight(null));

        this.setTitle("Mon Super Jeu - TP3");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        panel = new GameRender(dungeon, hero, gameState);
        this.getContentPane().add(panel);

        this.setFocusable(true);
        this.addKeyListener(this);

        this.setSize(new Dimension(
                dungeon.getWidth() * 32 + 20,
                dungeon.getHeight() * 32 + 40
        ));

        this.setVisible(true);
        this.requestFocusInWindow();

        // BOUCLE DE JEU
        Timer timer = new Timer(50, e -> {

            if (gameState == GameState.PLAYING) {

                if (hero.isAlive()) {
                    hero.moveIfPossible(hero.getSpeedX(), hero.getSpeedY(), dungeon);

                    hero.getHitBox().setX(hero.x);
                    hero.getHitBox().setY(hero.y);

                    // Collisions with traps and secret door
                    for (Things thing : dungeon.getRenderList()) {

                        if (thing instanceof Trap) {
                            Trap trap = (Trap) thing;
                            if (trap.getHitBox().intersect(hero.getHitBox())) {
                                hero.takeDamage(10);
                            }
                        }

                        if (thing instanceof SecretDoor) {
                            SecretDoor door = (SecretDoor) thing;
                            if (door.getHitBox().intersect(hero.getHitBox())) {
                                gameState = GameState.GAME_WON;
                                System.out.println("THE GAME IS WON !!!!!");
                                hero.setSpeedX(0);
                                hero.setSpeedY(0);
                                break;
                            }
                        }
                    }

                    // If hero died during this tick, switch to GAME_OVER
                    if (!hero.isAlive()) {
                        gameState = GameState.GAME_OVER;
                        hero.setSpeedX(0);
                        hero.setSpeedY(0);
                    }

                } else {
                    // Safety: if already dead
                    gameState = GameState.GAME_OVER;
                    hero.setSpeedX(0);
                    hero.setSpeedY(0);
                }
            }

            panel.setGameState(gameState);
            panel.repaint();

            for (Things thing : dungeon.getRenderList()) {

                if (thing instanceof Trap) {
                    Trap trap = (Trap) thing;
                    if (trap.getHitBox().intersect(hero.getHitBox())) {
                        hero.takeDamage(10);
                    }
                }

                if (thing instanceof DamageObstacle) {
                    DamageObstacle ob = (DamageObstacle) thing;
                    if (ob.getHitBox().intersect(hero.getHitBox())) {
                        hero.takeDamage(ob.getDamage());
                    }
                }
            }


        });

        timer.start();
    }

    private BufferedImage loadHeroSpriteFromSheet(String filePath, int tileX, int tileY) {
        try {
            BufferedImage sheet = ImageIO.read(new File(filePath));
            sheet = makeMagentaTransparent(sheet);
            int px = tileX * 32;
            int py = tileY * 32;
            BufferedImage sprite = sheet.getSubimage(px, py, 32, 32);
            System.out.println("HERO SPRITE = hero.png tile (" + tileX + "," + tileY + ")");
            return sprite;
        } catch (Exception e) {
            System.out.println("Impossible de charger hero.png : " + e.getMessage());
            return new BufferedImage(32, 32, BufferedImage.TYPE_INT_ARGB);
        }
    }

    private BufferedImage makeMagentaTransparent(BufferedImage src) {
        int w = src.getWidth();
        int h = src.getHeight();
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        int magenta = 0xFFFF00FF;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int rgb = src.getRGB(x, y);
                if (rgb == magenta) out.setRGB(x, y, 0x00000000);
                else out.setRGB(x, y, rgb);
            }
        }
        return out;
    }

    public static void main(String[] args) {
        try {
            new MainInterface();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("Touche pressée : " + KeyEvent.getKeyText(e.getKeyCode()));

        // TITLE SCREEN : SPACE to start
        if (gameState == GameState.TITLE_SCREEN && e.getKeyCode() == KeyEvent.VK_SPACE) {
            gameState = GameState.PLAYING;
            System.out.println("Partie lancée !");
            return;
        }

        // GAME OVER : R to restart
        if (gameState == GameState.GAME_OVER && e.getKeyCode() == KeyEvent.VK_R) {
            hero.reset(320, 320);
            hero.setSpeedX(0);
            hero.setSpeedY(0);
            gameState = GameState.PLAYING;
            System.out.println("Partie relancée !");
            return;
        }

        // GAME WON : R to restart
        if (gameState == GameState.GAME_WON && e.getKeyCode() == KeyEvent.VK_R) {
            hero.reset(320, 320);
            hero.setSpeedX(0);
            hero.setSpeedY(0);
            gameState = GameState.PLAYING;
            System.out.println("Nouvelle partie !");
            return;
        }

        // Controls only while playing
        if (gameState != GameState.PLAYING) return;

        switch (e.getKeyCode()) {
            case KeyEvent.VK_RIGHT:
                hero.setSpeedX(5);
                break;
            case KeyEvent.VK_LEFT:
                hero.setSpeedX(-5);
                break;
            case KeyEvent.VK_UP:
                hero.setSpeedY(-5);
                break;
            case KeyEvent.VK_DOWN:
                hero.setSpeedY(5);
                break;

            case KeyEvent.VK_1:
                hero.image = loadHeroSpriteFromSheet("src/resources/hero.png", 0, 0);
                break;
            case KeyEvent.VK_2:
                hero.image = loadHeroSpriteFromSheet("src/resources/hero.png", 1, 0);
                break;
            case KeyEvent.VK_3:
                hero.image = loadHeroSpriteFromSheet("src/resources/hero.png", 2, 0);
                break;
            case KeyEvent.VK_4:
                hero.image = loadHeroSpriteFromSheet("src/resources/hero.png", 3, 0);
                break;
        }

        if (e.getKeyCode() >= KeyEvent.VK_1 && e.getKeyCode() <= KeyEvent.VK_4) {
            hero.getHitBox().setWidth(hero.image.getWidth(null));
            hero.getHitBox().setHeight(hero.image.getHeight(null));
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (gameState != GameState.PLAYING) return;

        if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_LEFT) {
            hero.setSpeedX(0);
        }
        if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_DOWN) {
            hero.setSpeedY(0);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) { }
}

