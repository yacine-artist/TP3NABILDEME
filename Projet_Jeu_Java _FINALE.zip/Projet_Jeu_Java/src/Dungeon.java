import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Dungeon {

    private ArrayList<Things> renderList = new ArrayList<>();
    private char[][] map;
    private int width;
    private int height;
    private final Integer tileSizeW = 32;
    private final Integer tileSizeH= 32;

    public Dungeon(String fileName) throws IOException {

        try {
            loadMap(fileName);
            buildMap();
        } catch (IOException e) {
            System.out.println("Erreur map : " + e.getMessage());
            width = 10;
            height = 10;
            map = new char[width][height];
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    if (x == 0 || y == 0 || x == width - 1 || y == height - 1) {
                        map[x][y] = 'W';
                    } else {
                        map[x][y] = ' ';
                    }
                }
            }
            buildMap();
        }
    }

    private void loadMap(String fileName) throws IOException {
        ArrayList<String> lines = new ArrayList<>();

        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = br.readLine()) != null) {
            if (!line.trim().isEmpty()) {
                lines.add(line);
            }
        }
        br.close();

        if (lines.isEmpty()) {
            throw new IOException("Fichier vide");
        }

        width = 0;
        for (String l : lines) {
            if (l.length() > width) {
                width = l.length();
            }
        }
        height = lines.size();
        map = new char[width][height];

        for (int y = 0; y < height; y++) {
            String l = lines.get(y);
            for (int x = 0; x < width; x++) {
                if (x < l.length()) {
                    map[x][y] = l.charAt(x);
                } else {
                    map[x][y] = ' ';
                }
            }
        }
        System.out.println("Dungeon map loaded");
    }

    public BufferedImage loadAsset(String resourcePath) throws IOException {
        return ImageIO.read(new File(resourcePath));
    }
    private void buildMap() throws IOException {
        renderList.clear();
        Image grass = loadAsset("src/resources/graphics/grass.png");
        Image path  = loadAsset("src/resources/graphics/path.png");
        Image wallTree1 = loadAsset("src/resources/graphics/walltree1.png");
        Image wallTree2 = loadAsset("src/resources/graphics/walltree2.png");
        Image trapSpikes = loadAsset("src/resources/graphics/trapSkies.png");
        Image trapAlt = loadAsset("src/resources/graphics/trapAlt.png");
        Image flower = loadAsset("src/resources/graphics/flower_blue.png");
        Image water = loadAsset("src/resources/graphics/water_1.png");
        Image secretDoor = loadAsset("src/resources/graphics/secret_door_grass.png");
        Image spikeCrate = loadAsset("src/resources/graphics/obstacle_spikecrate.png");

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {

                int px = x * tileSizeW;
                int py = y * tileSizeH;
                char c = map[x][y];

                if (c == 'D') {
                    renderList.add(new Things(px, py, path));
                } else if (c == '~') {
                    renderList.add(new SolidThings(px, py, water));
                } else {
                    renderList.add(new Things(px, py, grass));
                }

                if (c == 'W') {
                    boolean variant = ((x + y) % 2 == 0);
                    Image wallImage = variant ? wallTree1 : wallTree2;
                    renderList.add(new WallTree(px, py, wallImage));
                }

                if (c == 'T') {
                    Image trapImage = (trapSpikes != null) ? trapSpikes : trapAlt;
                    renderList.add(new Trap(px, py, trapImage));
                }

                if (c == 'F') {
                    renderList.add(new Things(px, py, flower));
                }

                if (c == 'S') {
                    renderList.add(new SecretDoor(px, py, secretDoor));
                }

                if (c == 'B') {
                    renderList.add(new DamageObstacle(px, py, spikeCrate, 10));
                }
            }
        }
    }

    public ArrayList<Things> getRenderList() {
        return renderList;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
