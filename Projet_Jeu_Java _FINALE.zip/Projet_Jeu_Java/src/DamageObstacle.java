import java.awt.Image;

public class DamageObstacle extends SolidThings {
    private final int damage;

    public DamageObstacle(int x, int y, Image image, int damage) {
        super(x, y, image);
        this.damage = damage;
    }

    public int getDamage() {
        return damage;
    }
}
