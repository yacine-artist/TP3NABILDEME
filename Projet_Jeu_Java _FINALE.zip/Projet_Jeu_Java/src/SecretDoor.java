import java.awt.*;

public class SecretDoor extends Things {
    private Hitbox hitBox;
    public SecretDoor(int x, int y, Image img) {
        super(x, y, img);
        hitBox = new Hitbox(x, y, width, height);
    }
    public Hitbox getHitBox() {
        return hitBox;
    }
}
